
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * @brief defines a course name/code and enrolls sutudents into the course as well as prints the top studnet and how many students passed
 * 
 * @return
 */

int main()
{
  srand((unsigned) time(NULL));
  // creates a course with a name and code
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  // loop used to enroll random students into the course 
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  // prints each student that passes the course
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}