/**
 * @file course.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief Enrolls a student into a course
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // if they are the first student in the course then calloc memory for the new student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // else realloc memory for the new student as well as the old students 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief Prints the course name, course code, total number of students, and each students information
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // print each student information
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Returns the first student with the highest average in the course
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  //returns null if there are no students in the course
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  // loops through each student in the course comparing their average to the max average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // replaces the max average if the current student has a higher average
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief Returns the number of students with an average greater than or equal to the given grade
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // loops through each student in the course
  for (int i = 0; i < course->total_students; i++) 
  // finds the number of students that pass
    if (average(&course->students[i]) >= 50) count++;
  // new array with size of the number of students that pass
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // loops through each student in the course
  for (int i = 0; i < course->total_students; i++)
  {
    // adds the student that pass to the passing array
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}